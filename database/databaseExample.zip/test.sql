-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 13-08-2023 a las 15:27:12
-- Versión del servidor: 10.10.2-MariaDB-log
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `test`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mymap_filter`
--

CREATE TABLE `mymap_filter` (
  `id_filter` int(11) NOT NULL,
  `id_map` int(11) NOT NULL,
  `name` varchar(90) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mymap_filter_spot`
--

CREATE TABLE `mymap_filter_spot` (
  `id_filter` int(11) NOT NULL,
  `id_hotspot` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mymap_hotspot`
--

CREATE TABLE `mymap_hotspot` (
  `id_hotspot` int(11) NOT NULL,
  `id_map` int(11) NOT NULL,
  `latitude` varchar(50) NOT NULL,
  `longitude` varchar(50) NOT NULL,
  `id_image` int(11) DEFAULT NULL,
  `id_spot` int(11) NOT NULL,
  `information` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `mymap_hotspot`
--

INSERT INTO `mymap_hotspot` (`id_hotspot`, `id_map`, `latitude`, `longitude`, `id_image`, `id_spot`, `information`) VALUES
(1, 2, '453', '345', 1, 2, 'affas'),
(2, 2, '1231', '123', 2, 1, 'daf'),
(3, 2, '323', '23', 21, 1, 'dsf'),
(4, 2, '323', '23', 21, 2, 'dsf'),
(10, 2, '123', '567', NULL, 2, 'qweert');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mymap_images`
--

CREATE TABLE `mymap_images` (
  `id_image` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `ext` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `mymap_images`
--

INSERT INTO `mymap_images` (`id_image`, `name`, `ext`) VALUES
(1, 'https://drimjuguetes.vtexassets.com/arquivos/ids/821061-800-auto?v=637705548931330000&width=800&height=auto&aspect=true', 1),
(2, 'https://m.media-amazon.com/images/I/61eOPmucQRL._AC_SX425_.jpg', 1),
(20, 'adsf', 1),
(21, 'https://i.stack.imgur.com/RP4d0.png', 1),
(22, 'https://i.stack.imgur.com/RP4d0.png', 1),
(23, 'https://i.stack.imgur.com/RP4d0.png', 1),
(24, 'https://i.stack.imgur.com/RP4d0.png', 1),
(25, 'https://i.stack.imgur.com/RP4d0.png', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mymap_map`
--

CREATE TABLE `mymap_map` (
  `id_map` int(11) NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `configuration` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `mymap_map`
--

INSERT INTO `mymap_map` (`id_map`, `title`, `configuration`, `created_at`, `updated_at`, `description`) VALUES
(1, 'eeasdsad', '   {\n	\"zoom\": 6,\n	\"provider\" : \"https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png\",\n	 \"coord\":{\n	        \"lon\":-8.396,\n	        \"lat\":43.3713\n	    } \n        }', '2021-12-12 19:28:58', '2022-12-21 16:06:08', 'asdfasdf'),
(2, 'Este es un mapa de pruebaaa', '{\"zoom\":\"6\",\"provider\":\"https:\\/\\/{s}.tile.openstreetmap.org\\/{z}\\/{x}\\/{y}.png\",\"coord\":{\"lon\":\"43.3713\",\"lat\":\"-8.396\"}}', '2021-12-12 19:28:58', '2023-08-06 17:03:40', 'vaya');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mymap_spot`
--

CREATE TABLE `mymap_spot` (
  `id_spot` int(11) NOT NULL,
  `nombre` varchar(90) NOT NULL,
  `descripcion` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `id_image` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `mymap_spot`
--

INSERT INTO `mymap_spot` (`id_spot`, `nombre`, `descripcion`, `id_image`) VALUES
(1, 'aaaaaaaa', 'adsfadsf', 1),
(2, '3223', 'adsfadsf', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mymap_token`
--

CREATE TABLE `mymap_token` (
  `id_token` bigint(20) NOT NULL,
  `id_user` bigint(20) NOT NULL,
  `token` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `validation_token` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `date_exp` datetime NOT NULL COMMENT 'token expiration date',
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `type` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `mymap_token`
--

INSERT INTO `mymap_token` (`id_token`, `id_user`, `token`, `validation_token`, `date_exp`, `active`, `type`) VALUES
(2, 1, 'b032ed55f09094994f2cf971e210fd8c', '$2y$10$iMwzijW/Cwkl77d8p.NoluYNGkVcR9n82JPPb.J0yhdBswwkhg7ru', '2024-04-06 15:50:44', 1, 1),
(3, 1, '101ccb3f0a8d7ba971c4a24f30dc0245', '$2y$10$jGZU0AgM5HHJQOJAg1J3merXRlQb/t95IEcWMRTqPY5cgc5iaa8QW', '2024-08-12 15:21:44', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mymap_users`
--

CREATE TABLE `mymap_users` (
  `id_user` bigint(20) NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `pass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_add` datetime NOT NULL,
  `date_update` datetime NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `mymap_users`
--

INSERT INTO `mymap_users` (`id_user`, `email`, `pass`, `name`, `date_add`, `date_update`, `active`) VALUES
(1, '11@11.com', '$2y$10$kzwuoqc51t8p9lEzvOD4DeBmkqIpP8z73u6VwKzCRf9O9zoaFU8Bm', 'test', '2021-10-15 19:23:30', '2022-08-27 19:29:05', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `mymap_filter`
--
ALTER TABLE `mymap_filter`
  ADD PRIMARY KEY (`id_filter`),
  ADD KEY `mymap_filter` (`id_map`);

--
-- Indices de la tabla `mymap_filter_spot`
--
ALTER TABLE `mymap_filter_spot`
  ADD KEY `filter` (`id_filter`),
  ADD KEY `spot` (`id_hotspot`);

--
-- Indices de la tabla `mymap_hotspot`
--
ALTER TABLE `mymap_hotspot`
  ADD PRIMARY KEY (`id_hotspot`),
  ADD KEY `mymap_hotspot` (`id_map`),
  ADD KEY `map_image` (`id_image`),
  ADD KEY `map_spot` (`id_spot`);

--
-- Indices de la tabla `mymap_images`
--
ALTER TABLE `mymap_images`
  ADD PRIMARY KEY (`id_image`);

--
-- Indices de la tabla `mymap_map`
--
ALTER TABLE `mymap_map`
  ADD PRIMARY KEY (`id_map`),
  ADD KEY `title` (`title`);

--
-- Indices de la tabla `mymap_spot`
--
ALTER TABLE `mymap_spot`
  ADD PRIMARY KEY (`id_spot`),
  ADD KEY `mymap_spot` (`id_image`);

--
-- Indices de la tabla `mymap_token`
--
ALTER TABLE `mymap_token`
  ADD PRIMARY KEY (`id_token`),
  ADD KEY `token` (`token`),
  ADD KEY `user_token` (`id_user`);

--
-- Indices de la tabla `mymap_users`
--
ALTER TABLE `mymap_users`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `mymap_filter`
--
ALTER TABLE `mymap_filter`
  MODIFY `id_filter` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `mymap_hotspot`
--
ALTER TABLE `mymap_hotspot`
  MODIFY `id_hotspot` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `mymap_images`
--
ALTER TABLE `mymap_images`
  MODIFY `id_image` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de la tabla `mymap_map`
--
ALTER TABLE `mymap_map`
  MODIFY `id_map` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `mymap_spot`
--
ALTER TABLE `mymap_spot`
  MODIFY `id_spot` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `mymap_token`
--
ALTER TABLE `mymap_token`
  MODIFY `id_token` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `mymap_users`
--
ALTER TABLE `mymap_users`
  MODIFY `id_user` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `mymap_filter`
--
ALTER TABLE `mymap_filter`
  ADD CONSTRAINT `mymap_filter` FOREIGN KEY (`id_map`) REFERENCES `mymap_map` (`id_map`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `mymap_filter_spot`
--
ALTER TABLE `mymap_filter_spot`
  ADD CONSTRAINT `filter` FOREIGN KEY (`id_filter`) REFERENCES `mymap_filter` (`id_filter`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `spot` FOREIGN KEY (`id_hotspot`) REFERENCES `mymap_hotspot` (`id_hotspot`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `mymap_hotspot`
--
ALTER TABLE `mymap_hotspot`
  ADD CONSTRAINT `map_image` FOREIGN KEY (`id_image`) REFERENCES `mymap_images` (`id_image`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `map_spot` FOREIGN KEY (`id_spot`) REFERENCES `mymap_spot` (`id_spot`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `mymap_hotspot` FOREIGN KEY (`id_map`) REFERENCES `mymap_map` (`id_map`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `mymap_spot`
--
ALTER TABLE `mymap_spot`
  ADD CONSTRAINT `mymap_spot` FOREIGN KEY (`id_image`) REFERENCES `mymap_images` (`id_image`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `mymap_token`
--
ALTER TABLE `mymap_token`
  ADD CONSTRAINT `user_token` FOREIGN KEY (`id_user`) REFERENCES `mymap_users` (`id_user`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
